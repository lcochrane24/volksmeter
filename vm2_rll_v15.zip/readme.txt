Please make xx of these boards using standard thickness and board material etc.

Board Name: VM2_RLL
Version 1.5

Contact and shipping info:
