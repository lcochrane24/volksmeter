/* utils.c */

BYTE XmitCount()
{
	return txOutCount;
}

/* Calculate the checksum of a block of data */
BYTE CalcChecksum(BYTE *cp, WORD cnt)
{
	BYTE sum;

	sum = 0;
	while( cnt-- )
		sum ^= *cp++;
	return( sum );
}

char *SkipComma(char *line, int skip)
{
	while( --skip )  {
		if( *line == ',' )  {
			++line;
			continue;
		}
		if( ! ( line = strchr( line, ',' ) ) )
			return( (char *)0 );
		++line;
	}
	return( line );
}

BYTE GetHMS(char *ptr)
{
	BYTE num;
	
	num = ( *ptr++ - '0' ) * 10;	
	num += ( *ptr - '0' );
	return( num );
}

void SendGPS()
{
	--tx2OutCount;
	IFS1bits.U2TXIF = 0;
	U2TXREG = *tx2OutPtr++;
	IEC1bits.U2TXIE = 1;
}

void SendHost()
{
	--txOutCount;
	IFS0bits.U1TXIF = 0;
	U1TXREG = *txOutPtr++;
	IEC0bits.U1TXIE = 1;
}

/* Packs and sends a new debug / error message string to the host */
void SendLogString()
{
	PreHdr *phdr;
	BYTE sum, len;
	
	while( XmitCount() );
	
	memcpy( auxPacket, hdrStr, 4 );
	len = strlen( logStr ) + 1;		// 1 more for null
	phdr = (PreHdr *)auxPacket;
	phdr->len = len + 1;			// 1 more for checksum
	phdr->type = 'L';
	phdr->flags = 0x40;
	memcpy( &auxPacket[ sizeof(PreHdr) ], logStr, len );
	sum = CalcChecksum( &auxPacket[ 4 ], len + 4 );
	auxPacket[ len + sizeof(PreHdr) ] = sum; 
	txOutCount = len + ( sizeof( PreHdr ) + 1 );	// one more for the checksum
	txOutPtr = auxPacket;
	SendHost();
	sendLog = 0;
}

/* Packs and sends the time differece packet */
void SendLocTime()
{
	PreHdr *phdr;
	BYTE sum, len;
	
	while( XmitCount() );
	
	memcpy( auxPacket, hdrStr, 4 );
	len = sizeof( LocInfo );
	phdr = (PreHdr *)auxPacket;
	phdr->len = len + 1;			// 1 more for checksum
	phdr->type = 'w';
	phdr->flags = 0x40;
	memcpy( &auxPacket[ sizeof(PreHdr) ], &locInfo, len );
	sum = CalcChecksum( &auxPacket[ 4 ], len + 4 );
	auxPacket[ len + sizeof(PreHdr) ] = sum; 
	txOutCount = len + ( sizeof( PreHdr ) + 1 );	// one more for the checksum
	txOutPtr = auxPacket;
	SendHost();
	sendLoc = 0;
}

/* This "I am here" packet is sent if the A/D board is not communicating with the host. */
void SendConfigReq()
{
	PreHdr *pHdr;
	BYTE sum, len;
	BoardInfoVM *bi;
	
	len = sizeof( BoardInfoVM );
	memcpy( auxPacket, hdrStr, 4 );
	pHdr = (PreHdr *)auxPacket;
	pHdr->len = len + 1;			// 1 more for checksum
	pHdr->type = 'C';
	pHdr->flags = 0x40;		// new board
	
	bi = (BoardInfoVM *)&auxPacket[ sizeof(PreHdr) ];
	bi->notUsed = 0;
	bi->numConverters = numConverters;
	sum = CalcChecksum( &auxPacket[4], len + 4);
	auxPacket[ len + sizeof( PreHdr ) ] = sum;
	txOutCount = len + sizeof( PreHdr ) + 1;	// one more for the checksum
	txOutPtr = auxPacket;
	SendHost();
}

void WaitForConfig()
{
	WORD sendCount, ledCount;
	BYTE onOff;
	BYTE baud;
			
	hdrState = newCommandFlag = onOff = 0;
	ledCount = sendCount = 1;
	LED_PIN = 0;
	txOutCount = 0;
	
	IEC0bits.T1IE = 0;
	IEC0bits.U1RXIE = 1;
	
	while( 1 )  {
		baud = ReadBaudSwitch();
		if( baud != baudSwitch )  {
			baudSwitch = baud;
			SetBaudRate( TRUE );
		}
		if( newCommandFlag )  {
			newCommandFlag = 0;
			hdrState = 0;
			if( inBuffer[0] == 'b' )
				GotoBootLdr();
			else if( inBuffer[0] == 'C' )  {
				NewConfig();
				if( !initErr )
					return;
			}
		}
		--sendCount;
		if( !sendCount )  {
			SendConfigReq();
			sendCount = 100;
		}
		DelayMs(10);
		--ledCount;
		if( !ledCount )  {
			if( onOff )  {
				LED_PIN = 0;
				onOff = 0;
			}
			else  {
				LED_PIN = 1;
				onOff = 1;
			}
			ledCount = 10;
		}
	}
}

void SendStats()
{
	BYTE sum, len;
	StatusInfo *s;
	PreHdr *pHdr;
				
	len = sizeof( StatusInfo );
	s = (StatusInfo *)&auxPacket[ sizeof( PreHdr ) ];
	s->boardType = BOARD_TYPE;			// fill in the packet with data
	s->majVer = MAJOR_VER;
	s->minVer = MINOR_VER;
	s->numChannels = numChannels;
	s->sps = spsRate;
	
	memcpy( auxPacket, hdrStr, 4 );
	pHdr = (PreHdr *)auxPacket;
	pHdr->len = len + 1;			// 1 more for checksum
	pHdr->type = 'S';
	pHdr->flags = 0x40;
	sum = CalcChecksum(&auxPacket[4], len + 4);
	auxPacket[ len + sizeof(PreHdr) ] = sum; 
		
	txOutCount = len + ( sizeof( PreHdr ) + 1 );	// one more for the checksum
	txOutPtr = auxPacket;
	SendHost();
	sendStatus = 0;
}

void GotoBootLdr()
{
	asm ("RESET");
}

void SetTimeInfo()
{
	TimeInfo *ti;
	long time, diff;
	BYTE reset;
		
	memcpy( &inBuffer[0], &inBuffer[1], sizeof( TimeInfo ) );
	ti = (TimeInfo *)&inBuffer;
	time = ti->timeTick;
	reset = ti->reset;
	addTime = subTime = 0;
	
	IEC0bits.T1IE = 0;

	diff = timeTick - timeStamp;
	time += diff;
	if( time >= 86400000L )
		time -= 86400000L;
	timeTick = time;
	if( reset )  {
		sampleTimer = (200 - ( time % 200 ) ) << 1; 
		if( sampleTimer < 3 )
			sampleTimer += 200;
		secTick = ( 1000 - ( time % 1000 ) ) << 1;
		newPacketCount = sampleWait = 0;
		newSampleFlag = newWaitFlag = newPacketFlag = 0;
		sampleCount = 0;
	}
	IEC0bits.T1IE = 1;
}

void SetTimeDiff()
{
	SLONG diff;
	ULONG adiff;
	TimeDiffInfo *ti;
	BYTE reset;
				
	memcpy( &inBuffer[0], &inBuffer[1], sizeof( TimeDiffInfo ) );
	ti = (TimeDiffInfo *)&inBuffer;
	diff = ti->timeAdjust;
	reset = ti->reset;
	addTime = subTime = 0;
	
	IEC0bits.T1IE = 0;
	if( diff < 0 ) {
		adiff = -diff;
		if( adiff > timeTick )
			timeTick = 86400000L - ( adiff - timeTick );
		else
			timeTick -= adiff;
	}
	else  {
		timeTick += diff;
		if( timeTick >= 86400000L )
			timeTick -= 86400000L;
	}
	if( reset )  {
		sampleTimer = (200 - ( timeTick % 200 ) ) << 1; 
		if( sampleTimer < 3 )
			sampleTimer += 200;
		secTick = ( 1000 - ( timeTick % 1000 ) ) << 1;
		newPacketCount = sampleWait = 0;
		newSampleFlag = newWaitFlag = newPacketFlag = 0;
		sampleCount = 0;
	}
	IEC0bits.T1IE = 1;
}

void SendTimeDiff()
{
	SLONG now, diff;
	TimeInfo *ti;
	
	memcpy( &inBuffer[0], &inBuffer[1], sizeof( TimeInfo ) );
	IEC0bits.T1IE = 0;
	now = timeTick;
	IEC0bits.T1IE = 1;
	diff = now - timeStamp;
	ti = (TimeInfo *)&inBuffer;
	locInfo.data = now - ( ti->timeTick + diff );
	locInfo.msCount = 0;
	sendLoc = 1;
}

void SendAck()
{
	PreHdr *phdr;
	BYTE sum, len;
	
	memcpy( auxPacket, hdrStr, 4 );
	len = 1;
	
	phdr = (PreHdr *)auxPacket;
	phdr->len = len + 1;			// 1 more for checksum
	phdr->type = 'a';
	phdr->flags = 0x40;
	
	auxPacket[ sizeof(PreHdr) ] = 0x06;
	sum = CalcChecksum( &auxPacket[ 4 ], len + 4 );
	auxPacket[ len + sizeof(PreHdr) ] = sum; 
	
	txOutCount = len + ( sizeof( PreHdr ) + 1 );	// one more for the checksum
	txOutPtr = auxPacket;
	SendHost();
	sendAckFlag = 0;
}

void DelayMs( int ms )
{
	int i;
	long delay;
	
	for( i = 0; i != ms; i++ )  {
		delay = 1600L;
		while( delay-- );
	}
}

void SetBaudRate( int startInt )
{
	WORD div, c1, c2, data;
	
	if( newBoard )  {
		if( baudSwitch == 0 )
			div = 103;					// 4800
		else if( baudSwitch == 1 )
			div = 51;					// 9600
		else if( baudSwitch == 2 )
			div = 25;					// 19200
		else if( baudSwitch == 3 )
			div = 12;					// 38400
		else 
			div = 8;					// 57600
	}
	else  {
		if( baudSwitch == 0 )
			div = 8;
		else if( baudSwitch == 1 )	
			div = 12;
		else if( baudSwitch ==  2 )
			div = 25;
		else
			div = 51;
	}
	
	IEC0bits.U1TXIE = 0;
	IEC0bits.U1RXIE = 0;
	CloseUART1();
	c1 = UART_EN & UART_IDLE_CON & UART_DIS_WAKE & UART_DIS_LOOPBACK &
	    	UART_DIS_ABAUD & UART_NO_PAR_8BIT &	UART_1STOPBIT;
	c2 = UART_TX_PIN_NORMAL & UART_TX_ENABLE & UART_ADR_DETECT_DIS & 
		UART_RX_OVERRUN_CLEAR;
	OpenUART1( c1, c2, div  );
	
	if ( U1STAbits.OERR )
		U1STAbits.OERR = 0;
	
	data = U1STA;
	data &= 0xff3f;
	U1STA = data ;
	
	hdrState = 0;
	if( startInt )
		IEC0bits.U1RXIE = 1;
}

BYTE ReadBaudSwitch()
{
	WORD data;
	
	if( newBoard )  {
		data = 0;
		if( !SW1_BIT )
			data |= 0x01;
		if( !SW2_BIT )
			data |= 0x02;
		if( !SW3_BIT )
			data |= 0x04;
	}
	else  {
		data = PORTB;
		data >>= 10;
		data &= 0x03;
	}
	return (BYTE)data;
}
