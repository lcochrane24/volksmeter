/* sdrgps.c */

void NewGpsTimeNMEA()
{
	if( gpsSendState )
		return;
		
	if( gpsWaitLines )  {
		--gpsWaitLines;
		return;
	}
		
	if( !TestGpsLine() )
		return;
		
	if( !ParseGpsLine() )  {
		if( !sendGpsData && ( ++gpsBadCount >= 3 ) )  {
			gpsBadCount = 0;
			gpsSendState = 1;
			strcpy(logStr, "GPS Parse Error");
			sendLog = 1;
		}
		return;
	}
	
	gpsTimeOfDay = ( (long)gpsHour * 3600 ) + ( (long)gpsMin * 60 ) + (long)gpsSec;
	
	if( setGpsTimeFlag )
		SetGpsTime();
}
	
void SetGpsTime()
{
	ULONG gtime, adiff; 
	SLONG diff;
					
	while( XmitCount() );
	
	gtime = gpsTimeOfDay * 1000;
	
	if( !ppsTick )
		return;
	
	setGpsTimeFlag = 0;
	addTime = subTime = 0;
	
	IEC0bits.T1IE = 0;
	
	diff = gtime - ppsTick;
	if( diff < 0 ) {
		adiff = -diff;
		if( adiff > timeTick )
			timeTick = 86400000L - ( adiff - timeTick );
		else
			timeTick -= adiff;
	}
	else  {
		timeTick += diff;
		if( timeTick >= 86400000L )
			timeTick -= 86400000L;
	}
		
	secTick = ( 1000 - ( timeTick % 1000 ) ) << 1;
	
	if( resetTime )  {
		sampleTimer = (200 - ( timeTick % 200L ) ) << 1L; 
		if( sampleTimer < 3 )
			sampleTimer += 200;
		newPacketCount = sampleWait = 0;
		newSampleFlag = newWaitFlag = newPacketFlag = 0;
		sampleCount = 0;
		resetTime = 0;
	}
	
	IEC0bits.T1IE = 1;
}

BYTE GpsCommCheck()
{
	BYTE chr;
	
	if( gpsQueueInCount == gpsQueueOutCount )
		return 0;
	
	IEC1bits.U2RXIE = 0;
	chr = gpsInQueue[ gpsQueueOutCount ];
	if( ++gpsQueueOutCount >= GPS_IN_QUEUE )
		gpsQueueOutCount = 0;
	IEC1bits.U2RXIE = 1;

	if( sendGpsData && !gpsSendState )  {
		if( ++gpsOutLen >= (MAX_GPS_OUT_LEN-1) )  {
			if( gpsOutSendLen )  {
				ClearGpsOut();
				strcpy( logStr, "GPS Send Overflow Error");
				sendLog = 1;
				return 0;
			}
			else
				QueueGpsPacket();
		}
		*gpsOutBuffPtr++ = chr;
		gpsOutSum ^= chr;
	}

	if( chr == 0x0d )
		return 0;
	if( !gpsInCount )  {
		if( chr == '$' )  {
			gpsInCount = 1;
			gpsInBuffer[0] = chr;
		}
		return 0;
	}
	if( gpsInCount >= ( GPS_BUFFER_LEN-1 ) )  {
		gpsInCount = 0;
		strcpy( logStr, "GPS Input Overflow Error");
		sendLog = 1;
		return 0;
	}
	if( chr == 0x0a )  {
		gpsInBuffer[ gpsInCount ] = 0;
		gpsLineLen = gpsInCount+1;
		gpsInCount = 0;
		return 1;
	}
	gpsInBuffer[ gpsInCount++ ] = chr;
	return 0;
}

void QueueGpsPacket()
{
	BYTE *buff;
	PreHdr *pHdr;
	int len;

	if( gpsOutIdx )
		buff = gpsOutBuffer1; 
	else
		buff = gpsOutBuffer;
	
	pHdr = (PreHdr *)buff;
	memcpy( pHdr->hdr, hdrStr, 4);	// make the header
	len = gpsOutLen;
	pHdr->len = len + 1;			// 1 more for checksum
	pHdr->type = 'g';
	pHdr->flags = 0x40;
	gpsOutSum ^= buff[4];
	gpsOutSum ^= buff[5];
	gpsOutSum ^= buff[6];
	gpsOutSum ^= buff[7];
	buff[ len + sizeof(PreHdr) ] = gpsOutSum; 
	gpsOutSendPtr = buff;
	if( gpsOutIdx )  {
		gpsOutIdx = 0;
		gpsOutBuffPtr = &gpsOutBuffer[ sizeof( PreHdr ) ];	
	}
	else  {
		gpsOutIdx = 1;
		gpsOutBuffPtr = &gpsOutBuffer1[ sizeof( PreHdr ) ];	
	}
	gpsOutSum = gpsOutLen = 0;
	if( !skipGpsSend )
		gpsOutSendLen = len + ( sizeof( PreHdr ) + 1 );		// one more for the checksum
	skipGpsSend = 0;
}
	
BYTE TestGpsLine()
{
	char *ptr, *end, chr, *line;
	BYTE sum, num;
	WORD len;
	
	line = &gpsInBuffer[1]; 
	sum = 0;
	if(!( end = strchr( line, '*' ) ) )  {
		strcpy(logStr, "GPS Error No *");
		sendLog = 1;
		return( 0 );
	}
	*end++ = 0;
	if( ( len = strlen(line) ) < 2 )  {
		strcpy(logStr, "GPS Length Error");
		sendLog = 1;
		return( 0 );
	}
	ptr = line;
	while(len--)
		sum = sum ^ *ptr++;
	num = (sum >> 4) & 0x0f;
	if( num > 9 )
		chr = ( num-10 ) + 'A';
	else
		chr = num + '0';
	if( chr != *end++ )
		return( 0 );
	num = sum & 0x0f;
	if( num > 9 )
		chr = ( num-10 ) + 'A';
	else
		chr = num + '0';
	if( chr != *end )  {
		strcpy(logStr, "GPS Checksum Error");
		sendLog = 1;
		return(0);
	}
	return(1);
}

BYTE ParseGpsLine()
{
	char *ptr;
	
	if( !memcmp( &gpsInBuffer[1], gpsGGAStr, 6 ) )  {
		ptr = &gpsInBuffer[ 7 ];
		if( ! ( ptr = SkipComma( gpsInBuffer, 7 ) ) )
			return FALSE;
		gpsLockChar = *ptr;
		gpsSatNum = (char)GetHMS(ptr + 2);
		if( gpsLockChar == '0' || gpsSatNum <= 2 )
			currRmcTimer = rmcTimer = 255;
		return TRUE;
	}
	if( !memcmp( &gpsInBuffer[1], gpsRMCStr, 6 ) )  {
		ptr = &gpsInBuffer[ 7 ];
		gpsHour = GetHMS( ptr );
		gpsMin = GetHMS( &ptr[ 2 ] );
		gpsSec = GetHMS( &ptr[ 4 ] );
		if( ! ( ptr = SkipComma( gpsInBuffer, 10 ) ) )  {
			strcpy( logStr, "GPS RMC SkipComma Error");
			sendLog = 1;
			return FALSE;
		}
		if( *ptr == ',' )
			gpsDay = gpsMonth = 0;
		else  {
			gpsDay = GetHMS( ptr );
			gpsMonth = GetHMS( &ptr[ 2 ] );
			gpsYear = GetHMS( &ptr[ 4 ] );
		}
		if( gpsLockChar != '0' && gpsSatNum >= 2 )  {
			currRmcTimer = rmcTimer;
			rmcTimer = 0;
		}
		gpsBadCount = 0;
		rmcMsg = TRUE;
		return TRUE;
	}
	return FALSE;
}

void GetGpsLineGarmin( BYTE line )
{
	BYTE *out;
	BYTE len, sum, num; 
	
	switch( line )  {
		case 0:		strcpy( (char *)gpsOutLine, "$PGRMI,,,,,,,R" );
					break;
		case 1:		strcpy( (char *)gpsOutLine, "$PGRMO,,2" );
					break;
		case 2:		strcpy( (char *)gpsOutLine, "$PGRMO,GPGGA,1" );
					break;
		case 3:		strcpy( (char *)gpsOutLine, "$PGRMO,GPRMC,1" );
					break;
		case 4:		strcpy( (char *)gpsOutLine, "$PGRMC,,,,,,,,,,,,2,3,");
					break;
		default:	return;
			
	}
	len = strlen( (char *)gpsOutLine ) - 1;
	sum = CalcChecksum( &gpsOutLine[1], len );
	out = &gpsOutLine[ len + 1 ];
	*out++ = '*'; 
	num = ( sum >> 4 ) & 0x0f;
	if( num > 9 )
		*out++ = ( num - 10 ) + 'A';
	else
		*out++ = num + '0';
	num = sum & 0x0f;
	if( num > 9 )
		*out++ = ( num - 10 ) + 'A';
	else
		*out++ = num + '0';
	*out++ = 0x0d;
	*out++ = 0x0a;
	*out = 0;
	tx2OutPtr = gpsOutLine;
	tx2OutCount = strlen( (char *)gpsOutLine );
	SendGPS();
}

void GetGpsLineGarminAll( BYTE line )
{
	BYTE *out;
	BYTE len, sum, num; 
	
	switch( line )  {
		case 0:		strcpy( (char *)gpsOutLine, "$PGRMO,GPGSA,1" );
					break;
		case 1:		strcpy( (char *)gpsOutLine, "$PGRMO,GPRMC,1" );
					break;
		case 2:		strcpy( (char *)gpsOutLine, "$PGRMO,GPGSV,1" );
					break;
		case 3:		strcpy( (char *)gpsOutLine, "$PGRMO,PGRMT,1" );
					break;
		default:	return;
	}
	len = strlen( (char *)gpsOutLine ) - 1;
	sum = CalcChecksum( &gpsOutLine[1], len );
	out = &gpsOutLine[ len + 1 ];
	*out++ = '*'; 
	num = ( sum >> 4 ) & 0x0f;
	if( num > 9 )
		*out++ = ( num - 10 ) + 'A';
	else
		*out++ = num + '0';
	num = sum & 0x0f;
	if( num > 9 )
		*out++ = ( num - 10 ) + 'A';
	else
		*out++ = num + '0';
	*out++ = 0x0d;
	*out++ = 0x0a;
	*out = 0;
	tx2OutPtr = gpsOutLine;
	tx2OutCount = strlen( (char *)gpsOutLine );
	SendGPS();
}

void CheckSendGarmin()
{
	if( tx2OutCount || gpsSendWait )
		return;
		
	if( gpsSendState == 1 )  {
		gpsSendLine = 0;
		if( gpsReset )  {
			gpsReset = 0;
			GetGpsLineGarmin( gpsSendLine++ );
			gpsSendWait = 20;
		}
		else
			gpsSendLine = 1;
		gpsSendState = 2;
		return;
	}
	if( gpsSendState >= 2 && gpsSendState <= 5 )  {
		GetGpsLineGarmin( gpsSendLine++ );
		++gpsSendState;
		gpsSendWait = 10;
		return;
	}
	gpsWaitLines = 5;
	gpsSendState = 0;
	ClearGpsOut();
}

void CheckSendGarminAll()
{
	if( tx2OutCount || gpsSendWait )
		return;
		
	if( gpsSendState >= 1 && gpsSendState <= 4 )  {
		if( gpsSendState == 1 )
			gpsSendLine = 0;
		GetGpsLineGarminAll( gpsSendLine++ );
		++gpsSendState;
		gpsSendWait = 20;
		return;
	}
	sendAllGps = 0;
	gpsWaitLines = 5;
	gpsSendState = 0;
	ClearGpsOut();
}

void EchoGps()
{
	BYTE escCnt, chr;
	WORD c1, c2, data;
	escCnt = 0;
	SetGpsBaud( FALSE );
		
	CloseUART1();
	c1 = UART_EN & UART_IDLE_CON & UART_DIS_WAKE & UART_DIS_LOOPBACK &
	    	UART_DIS_ABAUD & UART_NO_PAR_8BIT &	UART_1STOPBIT;
	c2 = UART_TX_PIN_NORMAL & UART_TX_ENABLE & UART_ADR_DETECT_DIS & 
		UART_RX_OVERRUN_CLEAR;
	OpenUART1( c1, c2, 103  );
	
	data = U1STA;
	data &= 0xff3f;
	U1STA = data ;
		
	while( 1 )  {
		if( DataRdyUART1() )  {
			chr = ReadUART1();
			if( chr == 0x1b )  {
				if( ++escCnt >= 3 )
					break;
			}
			else
				escCnt = 0;
			while( BusyUART2() );
			WriteUART2( chr );
		}
		if( DataRdyUART2() )  {
			chr = ReadUART2();
			while( BusyUART1() );
			WriteUART1( chr );
		}
	}
	echoMode = 0;
	baudSwitch = ReadBaudSwitch();
	SetBaudRate( TRUE );
	InitGps();
}
		
void InitGps()
{
	if( !refGps )
		return;
	
	IEC1bits.U2TXIE = 0;
	IFS1bits.U2TXIF = 0;
	tx2OutCount = 0;
	SetGpsBaud( TRUE );
	gpsSendState = 1;
	while( 1 )  {
		GpsCommCheck();
		CheckSendGps();
		if( !gpsSendState )
			break;
		if( gpsSendWait )  {
			DelayMs( 250 );
			gpsSendWait = 0;
		}
		DelayMs( 1 );
	}
	gpsInCount = 0;
	SetGpsBaud( TRUE );
}

void CheckSendGps()
{
	if( sendAllGps )
		CheckSendGarminAll();
	else
		CheckSendGarmin();
}

void ClearGpsOut()
{
	gpsOutIdx = 0;
	gpsOutSendLen = gpsOutLen = gpsOutSum = 0;
	gpsOutBuffPtr = &gpsOutBuffer[ sizeof( PreHdr ) ];	
}

void SetGpsBaud( int startInt )
{
	WORD c1, c2, data;
	
	IEC1bits.U2TXIE = 0;
	IEC1bits.U2RXIE = 0;
	CloseUART2();
	
	c1 = UART_EN & UART_IDLE_CON & UART_DIS_WAKE & UART_DIS_LOOPBACK &
	    	UART_DIS_ABAUD & UART_NO_PAR_8BIT &	UART_1STOPBIT;
	c2 = UART_TX_PIN_NORMAL & UART_TX_ENABLE & UART_ADR_DETECT_DIS & 
		UART_RX_OVERRUN_CLEAR;
	OpenUART2( c1, c2, 103 );
	
	if ( U2STAbits.OERR )
		U2STAbits.OERR = 0;
	
	data = U2STA;
	data &= 0xff3f;
	U2STA = data ;
	
	gpsQueueInCount = gpsQueueOutCount = 0;
	if( startInt )
		IEC1bits.U2RXIE = 1;
}
