#include <stdio.h>
#include <uart.h>
#include <i2c.h>

#include "p30F4013.h"

_FOSC( CSW_FSCM_OFF & XT_PLL8 );
_FWDT( WDT_OFF );
_FBORPOR( PBOR_OFF & BORV_27 & PWRT_16 & MCLR_EN );
_FGS( CODE_PROT_OFF );

#define BYTE unsigned char

//#define LED_PIN			PORTFbits.RF0
#define LED_PIN				PORTBbits.RB8
//#define LED1_PIN			PORTDbits.RD0

BYTE hi, mid, low;

#include "I2CUtils.c"

BYTE Init()
{
	unsigned int c1, c2;
	
	ADCON1bits.ADON = 0;
	ADPCFG = 0x00ff;
	TRISB = 0xe0ff;
	TRISC = 0x0000;
	TRISD = 0xfdf0;
	TRISF = 0xffbc;
	TRISAbits.TRISA11 = 1;
	
	PORTD = 0x08;
	PORTBbits.RB8 = 0;
	
	c1 = UART_EN & UART_IDLE_CON & UART_DIS_WAKE & UART_DIS_LOOPBACK &
	  	UART_DIS_ABAUD & UART_NO_PAR_8BIT &	UART_1STOPBIT;

	c2 = UART_TX_PIN_NORMAL & UART_TX_ENABLE & UART_ADR_DETECT_DIS & 
		UART_RX_OVERRUN_CLEAR;
	
	OpenUART1( c1, c2, 51  );		// 19200 w/8Mhz
	
	return 1;
}

main()
{
	BYTE ret;
	long wait;
	int data;
			
	Init();
	
	while( 1 )  {
Restart:
		printf( "Startup\n");
			
		if( !I2CInit() )  {
			printf("I2C Init Error\n");
			DelayMs( 100 );
			continue;
		}
		
		I2CAdcStart();
		while( 1 )  {
			ret = I2CRead( 0x00 );
			if( !( ret & 0x04 ) )  {
				DelayMs(5);
				I2CReadSample();
				data = ( hi << 8 ) | mid;
				data -= 32768;
				printf("%x %x %x %d\n", hi, mid, low, data );
				I2CAdcStart();
				wait = 1000;
				while( 1 )  {
					if( I2CRead( 0x00 ) & 0x04 )
						break;
					--wait;
					if( !wait )  {
						printf("Read Error\n");
						goto Restart;
					}
				}
			}
		}
	}
}
