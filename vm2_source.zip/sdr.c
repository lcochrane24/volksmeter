/* sdr.c */

// 10/6/16 Made some changes to track down noise in the second channel. 
// Changing the output sequence from ch2 to ch1 did not effect the noise.

#ifdef CPU4013
#include "p30F4013.h"
#else
#include "p30F3014.h"
#endif

_FOSC( CSW_FSCM_OFF & XT_PLL4 );
_FWDT( WDT_OFF );
_FBORPOR( PBOR_OFF & BORV_27 & PWRT_16 & MCLR_EN );
_FGS( CODE_PROT_OFF );

#include <uart.h>
#include <i2c.h>
#include <stdio.h>
#include "sdr.h"

BYTE ppsLowHiFlag, addTime, subTime, setGpsTimeFlag, outBuffer;
BYTE newInData, sendLog, exitLoop, sendStatus, initErr, goodConfig;
BYTE ppsHiToLowFlag, ledPPS, newCommandFlag, checkErr, sendLoc, newBoard;
BYTE refGps, refLoc, echoMode, newEchoChr, rmcMsg, skipGpsSend;
BYTE sendAckFlag, cdcInitReg, cdcStart, skipInt, skipRead;
BYTE inBuffer[IN_BUFFER_SIZE], *inPtr;

BYTE newSampleFlag, newPacketFlag, newWaitFlag, addTimeLoopCount;
WORD newPacketCount, newPacketValue, resetTime;
 
#define MAX_DATA_LEN ( ( (80 * 3 * 3 ) / 5 ) + 100 )
#define DATA_LEN	( sizeof( PreHdr ) + sizeof( DataHdr ) + MAX_DATA_LEN )
BYTE dataPacket[DATA_LEN], dataPacket1[DATA_LEN], auxPacket[MAX_LOG_LINE], hdrStr[4], *txOutPtr;

char gpsInBuffer[ GPS_BUFFER_LEN ], gpsInQueue[ GPS_IN_QUEUE];
WORD gpsInCount, gpsQueueInCount, gpsQueueOutCount, newGpsData;

ULONG timeTick, ppsTick;

WORD secTick, secTickValue, secOffValue;
ULONG packetID, gpsTimeOfDay;

ULONG timeStamp;

BYTE adLoopCount, shiftNum, loopError, skipSample, skipSampleValue;
BYTE hi, mid, low, numConverters;

DataHdr *currHdr, *dummyHdr;
BYTE dummyPacket[ sizeof( PreHdr ) + sizeof( DataHdr ) + 4 ];

WORD sampleTimer, sampleTimerValue, txOutCount, sampleDataLen;
WORD sampleWait, sampleWaitTimer;

BYTE *adDataPtr, *adDataPtr2;

BYTE sampleCount, sampleCountTest, numChannels, secondChan, timeRefType;
WORD spsRate, commTimer;

ConfigInfo config;
BYTE baudSwitch;

BYTE gpsHour, gpsMin, gpsSec, sendHour, sendMin, sendSec;
BYTE gpsSatNum, gpsWaitLines, gpsMonth, gpsDay, gpsYear;
char gpsLockChar, gpsGGAStr[7], gpsRMCStr[7];

BYTE hdrState, inDataLen, inPacketLen;
BYTE inSum, echoChar;

BYTE gpsSendState, gpsBadCount, gpsSendWait, gpsSendLine, gpsLineLen;
BYTE gpsReset, gpsOutLine[GPS_OUT_LEN], *tx2OutPtr, tx2OutCount;

BYTE gpsOutBuffer[ MAX_GPS_OUT_LEN+sizeof(PreHdr)+4 ], gpsOutBuffer1[ MAX_GPS_OUT_LEN+sizeof(PreHdr)+4 ];
BYTE gpsOutSendLen, gpsOutLen, gpsOutSum, *gpsOutBuffPtr, *gpsOutSendPtr;
BYTE gpsOutIdx, sendGpsData, sendAllGps, sendNormalGps;

BYTE ch1Data, ch2Data, goodCh1, goodCh2;

char logStr[MAX_LOG_LINE];

LocInfo locInfo;
 
BYTE rmcTimer, currRmcTimer;

#include "utils.c"
#include "sdri2c.c"
#include "sdrgps.c"
#include "sdrint.c"

int main()
{
LoopIn:
	Init();
	Restart();
	
	numConverters = I2cTest();
		
	while( 1 )  {
		WaitForConfig();
		while( !exitLoop )  {
			while( 1 )  {
				if( newSampleFlag )  {
					if( !sampleCount )  {
						newPacketCount = 200;
						MakeHdr();
					}
					I2cAdcStart();
					if( addTimeLoopCount )  {
						addTime = 1;
						--addTimeLoopCount;
					}
					newSampleFlag = 0;
					continue;
				}
				if( newWaitFlag )  {
					NewSample();
					newWaitFlag = 0;
					continue;
				}
				if( refGps && GpsCommCheck() )  {
					NewGpsTimeNMEA();
					continue;
				}		
				if( newPacketFlag )  {
					newPacketFlag = 0;
					SendDummyPacket();
				}
				if( newCommandFlag )  {
					newCommandFlag = 0;
					hdrState = 0;
					NewCommand();
					if( exitLoop )
						break;
					continue;
				}
				if( !txOutCount )  {
					if( sendLoc )
						SendLocTime();
					else if( sendStatus ) 
						SendStats();
					else if( sendLog )
						SendLogString();
					else if( sendAckFlag )
						SendAck();
				}
			}
		}
	}
	goto LoopIn;
}

void NewSample()
{
	BYTE p = PORTB;
	
	if( skipRead )  {
		--skipRead;
		return;
	}
		
	if( numChannels == 1 )  {
		if( p & CH1_READY_MASK )  {
			strcpy( logStr, "CH1 Not RDY" );
			sendLog = 1;		
		}
	}	
	else  {	
		if( ( p & CH1_READY_MASK ) && ( p & CH2_READY_MASK ) )  {
			strcpy( logStr, "CH1 & CH2 Not RDY" );
			sendLog = 1;		
		}
		else if( p & CH1_READY_MASK )  {
			strcpy( logStr, "CH1 Not RDY" );
			sendLog = 1;		
		}
		else if( p & CH2_READY_MASK  )  {
			strcpy( logStr, "CH2 Not RDY!" );
			sendLog = 1;		
		}
	}
	
	I2cReadSample();

	if( ++sampleCount >= sampleCountTest )  {
		SendDataPacket();
		sampleCount = 0;
	}
}

void MakeHdr()
{
	if( outBuffer )  {
		currHdr = (DataHdr *)&dataPacket1[ sizeof( PreHdr ) ];
		adDataPtr = (BYTE *)&dataPacket1[ sizeof( PreHdr ) + sizeof( DataHdr ) ];
		adDataPtr2 = adDataPtr + 3;
	}
	else  {
		currHdr = (DataHdr *)&dataPacket[ sizeof( PreHdr ) ];
		adDataPtr = (BYTE *)&dataPacket[ sizeof( PreHdr ) + sizeof( DataHdr ) ];
		adDataPtr2 = adDataPtr + 3;
	}
	IEC0bits.T1IE = 0;
	currHdr->timeTick = timeTick;
	currHdr->ppsTick = ppsTick;
	IEC0bits.T1IE = 1;
	currHdr->gpsMonth = gpsMonth;
	currHdr->gpsDay = gpsDay;
	currHdr->gpsYear = gpsYear;
	currHdr->gpsTOD = gpsTimeOfDay;
	currHdr->gpsSatNum = gpsSatNum;
	currHdr->gpsLockSts = gpsLockChar;
	currHdr->loopError = loopError;
	currHdr->packetID = packetID + 1;
}

void SendDummyPacket()
{
	PreHdr *phdr;
	BYTE sum;
	WORD len;
		
	len = sizeof( DataHdr );
	
	while( XmitCount() );
		
	memcpy( dummyPacket, hdrStr, 4 );
	memcpy( dummyHdr, currHdr, sizeof( DataHdr ) );
	dummyHdr->packetID = packetID;
	phdr = (PreHdr *)dummyPacket;
	phdr->len = len + 1;			// one more for checksum
	phdr->type = 'D';
	phdr->flags = 0x40;
	sum = CalcChecksum( &dummyPacket[ 4 ], len + 4 );
	dummyPacket[ len + sizeof(PreHdr) ] = sum; 
	txOutPtr = dummyPacket;
	txOutCount = len + sizeof( PreHdr ) + 1;	// one more for the checksum
	SendHost();
	++packetID;
	Check100Ms();
}

void SendDataPacket()
{
	PreHdr *phdr;
	BYTE sum;
	WORD len;
		
	len = sampleDataLen + sizeof( DataHdr );
	
	while( XmitCount() );
		
	if( outBuffer )  {
		memcpy( dataPacket1, hdrStr, 4 );
		phdr = (PreHdr *)dataPacket1;
		phdr->len = len + 1;			// one more for checksum
		phdr->type = 'D';
		phdr->flags = 0x40;
		sum = CalcChecksum( &dataPacket1[ 4 ], len + 4 );
		dataPacket1[ len + sizeof(PreHdr) ] = sum; 
		txOutPtr = dataPacket1;
		outBuffer = 0;
	}
	else  {
		memcpy( dataPacket, hdrStr, 4 );
		phdr = (PreHdr *)dataPacket;
		phdr->len = len + 1;			// one more for checksum
		phdr->type = 'D';
		phdr->flags = 0x40;
		sum = CalcChecksum( &dataPacket[ 4 ], len + 4 );
		dataPacket[ len + sizeof(PreHdr) ] = sum; 
		txOutPtr = dataPacket;
		outBuffer = 1;
	}
	txOutCount = len + sizeof( PreHdr ) + 1;	// one more for the checksum
	SendHost();
	++packetID;
	Check100Ms();
}

void Check100Ms()
{
	if( gpsSendWait )
		--gpsSendWait;
	if( gpsSendState )
		CheckSendGps();
	if( hdrState && ( hdrState != 3 ) && ( ++commTimer >= 15 ) )  {
		hdrState = 0;
		strcpy( logStr, "Input Comm Timeout");
		sendLog = 1;
	}
	if( checkErr )  {
		checkErr = 0;
		strcpy( logStr, "Input Checksum Error");
		sendLog = 1;
	}
}

void NewConfig()
{
	while( XmitCount() );
	
	IFS0bits.U1RXIF = 0;		/* disable interrupts */
    IFS0bits.U1TXIF = 0;
	IFS1bits.U2RXIF = 0;		/* disable interrupts */
    IFS1bits.U2TXIF = 0;
	IEC0bits.T1IE = 0;
	
	memcpy( &config, &inBuffer[1], sizeof( ConfigInfo ) );
	
	numChannels = config.numChannels;
	timeRefType = config.timeRefType;
	timeTick = config.timeTick;
	
	if( timeRefType == TIME_REFV2_GARMIN )  {
		refGps = TRUE;
		refLoc = 0;
	}
	else if( timeRefType == TIME_REFV2_USEPC )  {
		refLoc = TRUE;
		refGps = 0;
	}		
	if( config.flags & 0x0001 )
		ppsHiToLowFlag = 1;
	else
		ppsHiToLowFlag = 0;

	if( !numChannels || ( numChannels > 2 ) )  {
		initErr = 1;
		numChannels = 1;
	}
	if( numChannels == 2 && numConverters < 2 )  {
		initErr = 1;
		numChannels = 1;
	}
	if( numChannels == 2 )
		secondChan = 1;
	else
		secondChan = 0;
	spsRate = config.sps;
	if( spsRate == 10 )  {
		sampleCountTest = 2;
		sampleTimerValue = TICKS_SPS_10;
		sampleWaitTimer = TICKS_10_WAIT;
		cdcInitReg = SPS_REG_INIT_10;
	}
	else if( spsRate == 20 )  {
		sampleCountTest = 4;
		sampleTimerValue = TICKS_SPS_20;
		sampleWaitTimer = TICKS_20_WAIT;
		cdcInitReg = SPS_REG_INIT_25;
	}
	else if( spsRate == 25 )  {
		sampleCountTest = 5;
		sampleTimerValue = TICKS_SPS_25;
		sampleWaitTimer = TICKS_25_WAIT;
		cdcInitReg = SPS_REG_INIT_25;
	}
	else if( spsRate == 40 )  {
		sampleCountTest = 8;
		sampleTimerValue = TICKS_SPS_40;
		sampleWaitTimer = TICKS_40_WAIT;
		cdcInitReg = SPS_REG_INIT_40;
	}
	else if( spsRate == 50 )  {
		sampleCountTest = 10;
		sampleTimerValue = TICKS_SPS_50;
		sampleWaitTimer = TICKS_50_WAIT;
		cdcInitReg = SPS_REG_INIT_50;
	}
	else if( spsRate == 80 )  {
		sampleCountTest = 16;
		sampleTimerValue = TICKS_SPS_80;
		sampleWaitTimer = TICKS_80_WAIT;
		cdcInitReg = SPS_REG_INIT_80;
	}
	else
		initErr = 1;
	
	if( config.flags & 0x0002 )
		ledPPS = 0;
	else
		ledPPS = 1;
	
	cdcStart = cdcInitReg;
	cdcStart |= 0x02;	
	I2cInit();
	
	Restart();
		
	if( initErr )
		exitLoop = 1;
	else  {
		exitLoop = 0;
		goodConfig = 1;
	}
}

void NewCommand()
{
	char cmd;
	
	cmd = inBuffer[0];
	if( cmd == 'T' )
		SetTimeInfo();
	else if( cmd == 'D' )
		SendTimeDiff();
	else if( cmd == 't' )  {
		setGpsTimeFlag = 1;
		resetTime = 0;
	}
	else if( cmd == 'i' )  {
		setGpsTimeFlag = 1;
		resetTime = 1;
	}
	else if( cmd == 'a' )  {
		addTimeLoopCount = 2;
		sendAckFlag = 1;
	}
	else if( cmd == 's' )  {
		subTime = 2;
		sendAckFlag = 1;
	}
	else if( cmd == 'S' )
		sendStatus = 1;
	else if( cmd == 'x')
		exitLoop = 1;
	else if( cmd == 'C' )
		NewConfig();
	else if( cmd == 'g' )  {
		gpsReset = 1;
		gpsSendState = 1;
		gpsSendWait = 0;
	}
	else if( cmd == 'G' )  {
		gpsSendState = 1;
		gpsSendWait = 0;
	}
	else if( cmd == 'E' )  {
		EchoGps();
		exitLoop = 1;
	}
	else if( cmd == 'b' )  {
		GotoBootLdr();
		sendAckFlag = 1;
	}
	else if( cmd == 'P' && !sendGpsData )  {
		sendGpsData = 1;
		sendAllGps = 1;
		gpsSendState = 1;
		skipGpsSend = 1;
		ClearGpsOut();
	}
	else if( cmd == 'p' && sendGpsData )  {
		sendAllGps = 0;
		sendGpsData = 0;
		sendNormalGps = 1;
		gpsSendState = 1;
		ClearGpsOut();
	}
	else if( cmd == 'd' )  {
		SetTimeDiff();
		sendAckFlag = 1;
	}
}

void Init()
{
	newBoard = 1;
	ADCON1bits.ADON = 0;
	ADPCFG = 0xffff;
	TRISA = 0;
	TRISC = 0;
	if( newBoard )  {	
		TRISB = 0x0e09;
		TRISD = 0x0100;
		TRISF = 0x0014;
		PORTB = 0x1fff;
	}
	else  {
		TRISB = 0x0e09;
		TRISD = 0x0104;
		TRISF = 0x001c;
		PORTB = 0x103f;
	}	
	
	SDA_CH2 = 1;
	SCL_CH2 = 1;
	SCL_OUT_CH2 = 0;
	SDA_OUT_CH2 = 0;
	
	SDA_CH1 = 1; 
	SCL_CH1 = 1; 
	SCL_OUT_CH1 = 0; 
	SDA_OUT_CH1 = 0; 
	
	TEST_PIN = 0;
	initErr = 0;
	
	baudSwitch = 0xff;
		
	TMR1 = 0; 				/* clear timer1 register */
	PR1 = 3999; 			/* set period1 register */
	T1CONbits.TCS = 0; 		/* set internal clock source */
	IPC0bits.T1IP = 0x06;	/* set priority level */
	IFS0bits.T1IF = 0; 		/* clear interrupt flag */
	T1CONbits.TON = 1; 		/* start the timer */
	SRbits.IPL = 3; 		/* enable CPU priority levels 4-7*/

	skipInt = 0;
	
	timeTick = 0;
	ledPPS = 0;
	numChannels = 1;
	spsRate = 20;
	sampleTimerValue = TICKS_SPS_25;
	sampleCountTest = 2;
	cdcInitReg = SPS_REG_INIT_25;
	
	timeRefType = 0;
	refGps = refLoc = 0;
	ppsHiToLowFlag = 0;
	sampleCountTest = 2;
		
	exitLoop = 0;
	DelayMs( 50 );
	sendLog = 0;
	newCommandFlag = checkErr = 0;
	goodConfig = 0;
	SetGpsBaud( 0 );
}

void Restart()
{
	initErr = 0;

	hdrStr[0] = 0xaa; hdrStr[1] = 0x55; hdrStr[2] = 0x88; hdrStr[3] = 0x44;
	
	outBuffer = 0;
	txOutCount = 0;
	packetID = 1;
	subTime = addTime = 0;
	
	ppsTick = 0;
	gpsTimeOfDay = 0;
	
	gpsLockChar = '0';
	gpsSatNum = 0;
	gpsSendState = 0;
	
	rmcMsg = rmcTimer = currRmcTimer = 0;
	
	sampleTimer = sampleTimerValue;
	secTick = secTickValue = 2000;
	secOffValue = 1000;
	
	sampleDataLen = ( ( spsRate * (WORD)numChannels ) / 5 ) * 3;
	
	newSampleFlag = newWaitFlag = newPacketFlag = 0;
	newPacketCount = newPacketValue = 0;
	sampleCount = 0;
	addTimeLoopCount = 0;
	
	sendLoc = 0;
	gpsInCount = gpsQueueInCount = gpsQueueOutCount = newGpsData = 0;
	loopError = hdrState = 0;
	gpsBadCount = tx2OutCount = 0;
	gpsReset = 0;
	setGpsTimeFlag = 0;
	gpsWaitLines = 5;
	gpsSendWait = 0;
	sendGpsData = sendAllGps = sendNormalGps = 0;
	echoMode = newEchoChr = 0;
	resetTime = 0;
	skipSample = 0;		
	skipGpsSend = 0;
	sendAckFlag = 0;
	skipRead = 2;
					
	dummyHdr = (DataHdr *)&dummyPacket[ sizeof( PreHdr ) ];
	
	strcpy( gpsGGAStr, "GPGGA,");
	strcpy( gpsRMCStr, "GPRMC,");
	gpsMonth = gpsDay = gpsYear = 0;
	
	ClearGpsOut();
	
	if( refGps )
		InitGps();
		
	if( ppsHiToLowFlag )  {
		if( !PPS_PIN )
			ppsLowHiFlag = 0;
		else
			ppsLowHiFlag = 1;
	}
	else  {
		if( PPS_PIN )
			ppsLowHiFlag = 0;
		else
			ppsLowHiFlag = 1;
	}
	
	IEC0bits.T1IE = 1;		/* enable interrupts */
	IEC0bits.U1RXIE = 1;
}
