// sdri2c.cpp

#define SPS_REG_INIT_10		0x30		// 10.9 Hz or 92.0 ms
#define SPS_REG_INIT_25		0x18		// 26.3 Hz or 38 ms
#define SPS_REG_INIT_40		0x10		// 50 Hz or 20 ms
#define SPS_REG_INIT_50		0x08		// 83 Hz or 11.9 ms
#define SPS_REG_INIT_80		0x00		// 90.9 Hz or 11 ms

// Delay for I2C R/W
void I2cDly(void)
{
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
	asm ("NOP");
}

// I2C start bit sequence
void I2cStart(void)
{
	SDA_CH2 = 1;
	SDA_CH1 = 1; 
  	I2cDly();
	SCL_CH2 = 1;
	SCL_CH1 = 1; 
  	I2cDly();
	SDA_CH2 = 0;
	SDA_CH1 = 0; 
  	I2cDly();
	SCL_CH2 = 0;
	SCL_CH1 = 0;
  	I2cDly();
}

// I2C stop bit sequence
void I2cStop(void)
{
	SDA_CH2 = 0;
	SDA_CH1 = 0; 
	I2cDly();
	SCL_CH2 = 1;
	SCL_CH1 = 1; 
	I2cDly();
	SDA_CH2 = 1;
	SDA_CH1 = 1; 
}

// Receive data from the CDC chips
void I2cRecv( BYTE ack )
{
	char x;
	BYTE p;
		
	ch1Data = 0;
	ch2Data = 0;
	
	SDA_CH2 = 1;
	SDA_CH1 = 1;
	for(x = 0; x < 8; x++ )  {
		ch1Data <<= 1; 
		ch2Data <<= 1;
		SCL_CH2 = 1;
		SCL_CH1 = 1;
		I2cDly();
		p = PORTB;
		if( p & CH1_IN_MASK )
			ch1Data |= 1;
		if( p & CH2_IN_MASK )
			ch2Data |= 1;
		SCL_CH2 = 0;
		SCL_CH1 = 0; 
  	}
	I2cDly();
	if( ack )  {
		SDA_CH2 = 0;
		SDA_CH1 = 0; 
	}
	else  {
		SDA_CH2 = 1;
		SDA_CH1 = 1; 
	}
	SCL_CH2 = 1;
	SCL_CH1 = 1; 
	I2cDly();
	SCL_CH2 = 0;
	SCL_CH1 = 0; 
	SDA_CH2 = 1;
	SDA_CH1 = 1; 
}

// Send data to the CDC chips
void I2cSend( BYTE d )
{
	BYTE i; // , ret1, ret2;
		
	for( i = 8; i; i-- )  {
	    if( d & 0x80 )  { 
			SDA_CH2 = 1;
			SDA_CH1 = 1; 
		}
		else  {
			SDA_CH2 = 0;
			SDA_CH1 = 0; 
		}
		I2cDly();
		SCL_CH2 = 1;
		SCL_CH1 = 1; 
	    d <<= 1;
		I2cDly();
		SCL_CH2 = 0;
    	SCL_CH1 = 0; 
	}
	SDA_CH2 = 1;
	SDA_CH1 = 1; 
	SCL_CH2 = 1;
	SCL_CH1 = 1; 
	I2cDly();
	SCL_CH2 = 0;
	SCL_CH1 = 0; 
}

void I2cWriteData( BYTE addr, BYTE data )
{
	I2cStart();
	I2cSend( 0x90 );
	I2cSend( addr );
	I2cSend( data );
	I2cStop();
}

void I2cReadSample()
{
	IEC1bits.U2RXIE = 0;
	
	I2cStart();
	I2cSend( 0x90 );
	I2cSend( 0x01 );
	I2cStart();
	I2cDly();
	I2cSend( 0x91 );
	
	I2cRecv(1);
	*adDataPtr++ = ch1Data;
	if( secondChan )
		*adDataPtr2++ = ch2Data;
	
	I2cRecv(1);
	*adDataPtr++ = ch1Data;
	if( secondChan )
		*adDataPtr2++ = ch2Data;
	
	I2cRecv(0);
	*adDataPtr++ = ch1Data;
	if( secondChan )  {
		*adDataPtr2++ = ch2Data;
		adDataPtr += 3;
		adDataPtr2 += 3;
	}
	IEC1bits.U2RXIE = 1;
}

void I2cTestChips( BYTE testVal )
{
	I2cStart();
	I2cSend( 0x90 );
	I2cSend( 0x08 );
	I2cSend( testVal );
	I2cStop();

	I2cDly();
	
	I2cStart();
	I2cSend( 0x90 );
	I2cSend( 0x08 );
	I2cStart();
	I2cSend( 0x91 );
	I2cRecv( 0 );
	I2cStop();
		
	if( ch1Data == testVal )
		++goodCh1;
	if( ch2Data == testVal )
		++goodCh2;
}

void I2cResetADC()
{
	DelayMs(1);
	I2cStart();
	I2cSend( 0x00 );				// General Call
	I2cSend( 0x06 );				// Reset
	DelayMs(2);
	I2cStop();
	DelayMs(10);
}

BYTE I2cTest()
{
	int count = 3;
		
	while( count-- )  {
		goodCh1 = goodCh2 = 0;
		I2cResetADC();
		I2cTestChips( 0x55 );
		I2cTestChips( 0xaa );
		I2cTestChips( 0x88 );
		I2cTestChips( 0x00 );
		if( goodCh2 == 4 && goodCh1 == 4 )
			return 2;
		if( goodCh1 == 4 )
			return 1;
	}
	return 0;
}

void I2cAdcStart()
{
	I2cWriteData( 0x0a, cdcStart );
}

void I2cInit()
{
	IEC1bits.U2RXIE = 0;
	I2cResetADC();
	I2cWriteData(0x07, 0xa0 );
	DelayMs(1);
	I2cWriteData(0x09, 0x5b );
	DelayMs(1);
	I2cWriteData(0x0a, cdcInitReg );
	DelayMs(1);
	IEC1bits.U2RXIE = 1;
}
