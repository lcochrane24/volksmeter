@echo off
if "%1" == "" goto nodata
set mkfile=sdr
:nodata
@ del /e /q %mkfile%.hex
@ del /e /q dsdr_3014*.hex
@"D:\dspic\C30\bin\pic30-gcc.exe" -O3 -DCPU3014 -mcpu=30F3014 -c "%mkfile%.c" -o"%mkfile%.o" -Wall  -fpack-struct
@"D:\dspic\C30\bin\pic30-gcc.exe" -Wl,""%mkfile%.o","D:\dspic\C30\lib\libp30F3014-coff.a",-L"D:\dspic\C30\lib",--script="D:\dspic\C30\support\gld\p30f3014.gld",--heap=32,--stack=128,-Map=""%mkfile%.map",--warn-section-align,-o""%mkfile%.cof"
@"D:\dspic\C30\bin\pic30-bin2hex.exe" "%mkfile%.cof"
ren %mkfile%.hex vmsdr_3014_v26.hex
:eof
