@echo off
if "%1" == "" goto nodata
set mkfile=sdr
:nodata
@ del /e /q %mkfile%.hex
@ del /e /q dsdr_4013*.hex
@"D:\dspic\C30\bin\pic30-gcc.exe" -O3 -DCPU4013 -mcpu=30F4013 -c "%mkfile%.c" -o"%mkfile%.o" -Wall  -fpack-struct
@"D:\dspic\C30\bin\pic30-gcc.exe" -Wl,""%mkfile%.o","D:\dspic\C30\lib\libp30F4013-coff.a",-L"D:\dspic\C30\lib",--script="D:\dspic\C30\support\gld\p30f4013.gld",--heap=32,--stack=128,-Map=""%mkfile%.map",--warn-section-align,-o""%mkfile%.cof"
@"D:\dspic\C30\bin\pic30-bin2hex.exe" "%mkfile%.cof"
ren %mkfile%.hex vmsdr_4013_v26.hex
:eof
